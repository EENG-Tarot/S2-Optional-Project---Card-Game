from code_tarot_definition import *
from code_tarot_interface import *


def game():

    p1 = []
    p2 = []
    p3 = []
    p4 = []
    chien = []
    introduction_text = ('Rules of tarot:\n'
                        '...\n'
                        '\n'
                        'Rules for the interface:\n'
                        '- when there are no buttons for this, close the window to move on to the next activity.\n'
                        '- look at the title of the window to see who the window is for.\n'
                        '\n'
                        'Created by : Valentine D, Arnaud RDB, Mathieu M\n'
                        'We wish you a good game !!!')
    Interface_Label('START', introduction_text)

    # step 1 : create the cards
    finalDeck = cardDeck()

    # step 3 : the dog
    draw(6, chien, finalDeck)

    # step 3bis : distribution
    p1 = card_sorted(distribution(p1, p1, p2, p3, p4, finalDeck))
    p2 = card_sorted(distribution(p2, p1, p2, p3, p4, finalDeck))
    p3 = card_sorted(distribution(p3, p1, p2, p3, p4, finalDeck))
    p4 = card_sorted(distribution(p4, p1, p2, p3, p4, finalDeck))

    # step 4 : organization of the dog
    for i in range(1,5):
        playercards = wichplayer(i, p1, p2, p3, p4)
        playerrank = i
        player_choice = CardsInterface_start(playercards, 'Here are your cards', 'Do you want to take the dog ?', f'Only for the player {playerrank}')
        list(player_choice.strip())
        if player_choice[0] == "Y" or player_choice[0] == "y" or player_choice[0] == "O" or player_choice[0] == "o":
            break

    if player_choice[0] == "N" or player_choice[0] == "n":
        return '\nNo one wants to take the dog\nGAME OVER'

    if playerrank == 1: player_alone = p1
    elif playerrank == 2: player_alone = p2
    elif playerrank == 3: player_alone = p3
    elif playerrank == 4: player_alone = p4
    elif playerrank == 5: player_alone = []

    print(INTERFACE_creation_of_the_chien(chien, player_alone))

    if playerrank == 1:
        p1 = card_sorted(player_alone)
    if playerrank == 2:
        p2 = card_sorted(player_alone)
    if playerrank == 3:
        p3 = card_sorted(player_alone)
    if playerrank == 4:
        p4 = card_sorted(player_alone)

    # step 5 : the game (18 rounds)

    p1cards = []
    p2cards = []
    p3cards = []
    p4cards = []
    whoPlaysFirst = [p1, p2, p3, p4]

    for i in range(18):

        m = 0
        pli = []

        for playerCard in whoPlaysFirst:

            if playerCard == p1: m = 1
            elif playerCard == p2: m = 2
            elif playerCard == p3: m = 3
            elif playerCard == p4: m = 4

            authorized_playerCard = cards_that_the_player_can_play(playerCard, pli)

            pn_r = CardsInterface_round(playerCard, authorized_playerCard, pli, f'Player {m}: here are the cards you can play', 'And here are the cards played by the other players for this round :', f"Only for player {m}")

            pli.append(authorized_playerCard[pn_r])

            card = authorized_playerCard[pn_r]
            playerCard.remove(card)










 # -------------------------------------------------------------------------------------------
 # A TOTALEMENT REVOIR

        #étape 5 bis : qui gagne ? ----------------------------------------------------------

        whoPlaysFirst = runningOrder(whoPlaysFirst, winner(pli))
        
        NbWinner = '0'
        if whoPlaysFirst[0] == p1:
            NbWinner = '1'
            for card in range(0, 4):
                p1cards.append(pli[card])
        elif whoPlaysFirst[0] == p2:
            NbWinner = '2'
            for card in range(0, 4):
                p2cards.append(pli[card])
        elif whoPlaysFirst[0] == p3:
            NbWinner = '3'
            for card in range(0, 4):
                p3cards.append(pli[card])
        elif whoPlaysFirst[0] == p4:
            NbWinner = '4'
            for card in range(0, 4):
                p4cards.append(pli[card])

        Interface_pli(pli, NbWinner, i+1)


    # etape 6 : les points -----------------------------------------------------------------


    dictA = reverse_card_classification()
    j = 0
    nbOfBou = 0
    for i in [p1cards, p2cards, p3cards, p4cards]:
        j = j+1
        if j == playerrank: # playerrank = rank of the player who takes the dog cf. step 4
            
            for m in i:
                if dictA.get(m) == 77: nbOfBou = nbOfBou + 1
                if dictA.get(m) == 78: nbOfBou = nbOfBou + 1
                if dictA.get(m) == 57: nbOfBou = nbOfBou + 1
            
            text1 = f"\n\n\n\nPlayer {j} you took the dog with {nbOfBou} oudlers and you finished with {PointsCount(i)} points"
            textL = "\n\n\nYou loose\n\n\n"
            textW = "\n\n\nYou win\n\n\n"

            if nbOfBou == 0:
                if PointsCount(i) >= 56: Interface_Label('END', text1 + textW)
                else: Interface_Label('END', text1 + textL)
            elif nbOfBou == 1:
                if PointsCount(i) >= 51: Interface_Label('END', text1 + textW)
                else: Interface_Label('END', text1 + textL)
            elif nbOfBou == 2:
                if PointsCount(i) >= 41: Interface_Label('END', text1 + textW)
                else: Interface_Label('END', text1 + textL)
            elif nbOfBou == 5:
                if PointsCount(i) >= 36: Interface_Label('END', text1 + textW)
                else: Interface_Label('END', text1 + textL)


    return 'END'

