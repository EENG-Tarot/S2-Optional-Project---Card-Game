from code_tarot_definition import PlayersWantToPlay
from code_tarot_principal import game

while PlayersWantToPlay():
    print(game())
