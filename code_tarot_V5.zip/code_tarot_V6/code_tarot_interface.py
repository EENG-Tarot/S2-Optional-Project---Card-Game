from tkinter import * 
from tkinter.ttk import *


def CardsInterface(listA, txtButton, txtTitle):
    """
    - at the input we give a list of cards in the form we used for the code (ex: [('1', 'H')])
    - it display the cards with tkinter
    - if you click on it, it destroys the window containing all the cards
    - the definition returns the rank in the listA of the selected card

    !!! for the files : they must be in png and 300 pixels high
        (so they have to be resized on the computer after downloading them)

    https://zestedesavoir.com/forums/sujet/15363/optimiser-mon-code-dinterface-tkinter/?page=1#p234474

    """

    root = Tk()
    root.title(txtTitle)

    Label(root, text = txtButton, font =('Verdana', 10)).pack()

    images = []
    for i in listA:
        if i[1] == 'H': shape = 'coeur'
        if i[1] == 'D': shape = 'carreaux'
        if i[1] == 'C': shape = 'treffles'
        if i[1] == 'S': shape = 'pic'
        

        def test(a, b):
            def test2():
                root.destroy()
                with open("CardChoosen.txt", "w") as f:
                    f.write("('{}', '{}')".format(a, b))
            return test2
        photo = PhotoImage(file ="{}\\{}_{}.png".format(shape, i[0], shape), height=300, width=198).subsample(3)
        images.append(photo)
        button = Button(root, image = photo, command=test(i[0], i[1]))
        button.pack(side = LEFT)

    root.mainloop()

    with open("CardChoosen.txt", "r") as f:
        otherVariable = f.read()

    print(otherVariable)

    for i in listA:
        if str(i) == otherVariable: return listA.index(i)


deck = [('1', 'H'), ('2', 'H'), ('C', 'H'), ('7', 'H'), ('8', 'H')]
deck2 = [('1','H'), ('K','H'), ('5','H'), ('C','D'), ('6','H')]
print(CardsInterface(deck, "choose", "player test"))
print(CardsInterface(deck2, "choose", "player test"))
