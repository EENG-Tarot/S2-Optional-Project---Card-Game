from os import execlp
from tkinter import * 
from tkinter.ttk import *
from code_tarot_definition import *


# ------------------------------------------------------------------------------------------------------------

def CardsInterface_round(CardList, PlayerList, cardsPlayedList, Playertext, cardsPlayedtext, TitleText):
    """
    - at the input we give a list of cards in the form we used for the code (ex: [('1', 'H')])
    - it display the cards with tkinter
    - if you click on it, it destroys the window containing all the cards
    - the definition returns the rank in the listA of the selected card

    !!! for the files :
    - they must be in png and 300 pixels high (so they have to be resized on the computer after downloading them)
    - name : value_color *color in french* (exemple : C_coeur, 1_treffles ...)

    https://zestedesavoir.com/forums/sujet/15363/optimiser-mon-code-dinterface-tkinter/?page=1#p234474

    Args:
        PlayerList (list): the player's cards
        cardsPlayedList (list): cards played by the previous players
        Playertext (str): write above the cards played by the previous players
        cardsPlayedtext (str): write above the player's cards

    Returns:
        int: the rank of the choosen card
    """

    # create the window

    root = Tk()
    root.title(TitleText)

    # create the frame to display the player's cards
    
    Cardframe = Frame(root)
    Label(Cardframe, text='Your cards').pack()

    CardImages = []
    for i in CardList:

        def test(item0, item1):
            def test2():
                root.destroy()
                with open("CardChoosen.txt", "w") as f:
                    f.write("('{}', '{}')".format(item0, item1))
            return test2

        photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
        CardImages.append(photo)
        button = Button(Cardframe, image = photo, command=test(i[0], i[1]))
        button.pack(side = LEFT)

    # create the frame to display the player's cards that he can play

    Playerframe = Frame(root)
    Label(Playerframe, text=Playertext).pack()

    playerImages = []
    for i in PlayerList:

        def test(item0, item1):
            def test2():
                root.destroy()
                with open("CardChoosen.txt", "w") as f:
                    f.write("('{}', '{}')".format(item0, item1))
            return test2

        photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
        playerImages.append(photo)
        button = Button(Playerframe, image = photo, command=test(i[0], i[1]))
        button.pack(side = LEFT)

    # create the frame to display previously played cards

    cardsPlayedframe = Frame(root)
    Label(cardsPlayedframe, text=cardsPlayedtext).pack()

    PliImages = []
    for i in cardsPlayedList:

        def test():
            pass
        photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
        PliImages.append(photo)
        button = Button(cardsPlayedframe, image = photo, command=test)
        button.pack(side = LEFT)

    # display the 2 frames

    Cardframe.pack(fill=X)
    Playerframe.pack(expand=YES)
    cardsPlayedframe.pack(expand=YES)
    root.mainloop()

    # return the rank of the chosen card

    with open("CardChoosen.txt", "r") as f:
        otherVariable = f.read()

    for j in PlayerList:
        if str(j) == otherVariable: return PlayerList.index(j)

# ------------------------------------------------------------------------------------------------------------

def CardsInterface_start(PlayerList, Playertext, Question, RootTitle):
    """
    - display to list of cards: PlayerList and DogList
    - ask a question (Question)
    - player can choose between a button Yes or No

    Args:
        PlayerList (list): the player's cards
        DogList (list): the dog's cards
        Playertext (str): 
        Dogtext (str): 
        Question (str): 

    Returns:
        str: Yes or No
    """

    # create the window

    root = Tk()
    root.title(RootTitle)

    # create the frame to display the player's cards

    Playerframe = Frame(root)
    Label(Playerframe, text=Playertext).pack()

    playerImages = []
    for i in PlayerList:

        def test():
            pass
        photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
        playerImages.append(photo)
        button = Button(Playerframe, image = photo, command=test)
        button.pack(side = LEFT)

    # display the 2 frames

    Playerframe.pack(expand=YES)

    # create the button
    
    Buttonframe = Frame(root)
    Label(Buttonframe, text=Question).pack()

    def Yes():
        root.destroy()
        with open("YesOrNo.txt", "w") as f:
            f.write("Yes")

    def No():
        root.destroy()
        with open("YesOrNo.txt", "w") as f:
            f.write("No")

    Button(Buttonframe, text='YES', command=Yes).pack(side = LEFT)
    Button(Buttonframe, text='NO', command=No).pack(side = LEFT)
    Buttonframe.pack(expand=YES)

    root.mainloop()

    with open("YesOrNo.txt", "r") as f:
        choice = f.read()

    if choice == "Yes": return "Yes"
    elif choice == "No": return "No"

# ------------------------------------------------------------------------------------------------------------

def INTERFACE_creation_of_the_chien(chien, player_alone):
    def player_choice_for_the_chien(DogList, PlayerList):
        def CardsInterface_DogCreation(PlayerList, DogList, Playertext, Dogtext):

            root = Tk()
            root.title('ONLY FOR THE PLAYER WHO TOOK THE DOG.')
            Label(root, text='RULES :\nClick on the cards you want to exchange. At the end there must be no king or assets left in the dog.\nBe careful if there is still an asset or a king in the dog the window will continue to appear even if you click on yes.\nPlease do not click the button if you have not selected the cards you want to exchange. There is a risk of bugs').pack()

            # PLAYER FRAME
            
            Playerframe = Frame(root)
            Label(Playerframe, text=Playertext).pack()

            playerImages = []
            for i in PlayerList:

                def test(item0, item1):
                    def test2():
                        Playerframe.destroy()
                        with open("CardChoosenPLAYER.txt", "w") as f:
                            f.write("('{}', '{}')".format(item0, item1))
                    return test2
                photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
                playerImages.append(photo)
                button = Button(Playerframe, image = photo, command=test(i[0], i[1]))
                button.pack(side = LEFT)

            Playerframe.pack(expand=YES)

            # DOG FRAME

            Dogframe = Frame(root)
            Label(Dogframe, text=Dogtext).pack()

            DogImages = []
            for i in DogList:

                def test(item0, item1):
                    def test2():
                        Dogframe.destroy()
                        with open("CardChoosenDOG.txt", "w") as f:
                            f.write("('{}', '{}')".format(item0, item1))
                    return test2
                photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
                DogImages.append(photo)
                button = Button(Dogframe, image = photo, command=test(i[0], i[1]))
                button.pack(side = LEFT)

            Dogframe.pack(expand=YES)

            # BUTTON FRAME

            Buttonframe = Frame(root)
            Label(Buttonframe, text='Do you finished ?').pack()

            def Yes():
                root.destroy()
                with open("YesOrNo.txt", "w") as f:
                    f.write("Yes")

            def No():
                root.destroy()
                with open("YesOrNo.txt", "w") as f:
                    f.write("No")

            Button(Buttonframe, text='YES', command=Yes).pack(side = LEFT)
            Button(Buttonframe, text='NO', command=No).pack(side = LEFT)
            Buttonframe.pack(expand=YES)

            # DISPLAY
            root.mainloop()

            # RETURN

            with open("CardChoosenPLAYER.txt", "r") as f:
                playercard = f.read()
            for j in PlayerList:
                if str(j) == playercard: playercard = PlayerList.index(j)

            with open("CardChoosenDOG.txt", "r") as f:
                dogcard = f.read()
            for j in DogList:
                if str(j) == dogcard: dogcard = DogList.index(j)

            with open("YesOrNo.txt", "r") as f:
                choice = f.read()

            if choice == "Yes": return [playercard, dogcard, "YES"]
            elif choice == "No": return [playercard, dogcard, "NO"]
        
        answer = CardsInterface_DogCreation(PlayerList, DogList, "Your cards:", "the dog cards:")

        card_chien = answer[1]
        card_hand = answer[0]

        card_chosen_from_the_chien = DogList[card_chien]
        card_chosen_from_the_hand = PlayerList[card_hand]

        DogList.remove(card_chosen_from_the_chien)
        DogList.append(card_chosen_from_the_hand)
        PlayerList.remove(card_chosen_from_the_hand)
        PlayerList.append(card_chosen_from_the_chien)

        return [DogList, PlayerList, answer[2]]

    m = 1
    while m == 1:

        DEFanswer = player_choice_for_the_chien(chien, player_alone)

        chien = DEFanswer[0]
        player_alone = DEFanswer[1]

        transformation = card_classification()

        listG = []
        for i in chien:
            value_i = transformation[i]
            listG.append(value_i)

        m = 0
        for i in range(0,6):
            if listG[i] == 14 or listG[i] == 28 or listG[i] == 42 or listG[i] == 56:
                m = 1
            for n in range(57,79):
                if listG[i] == n:
                    m = 1

    with open("YesOrNo.txt", "r") as f:
        DEFchoice = f.read()

    while DEFchoice == "No":
        INTERFACE_creation_of_the_chien(chien, player_alone)
        with open("YesOrNo.txt", "r") as f:
            DEFchoice = f.read()
    
    return f"\n\n\n\nfinally the chien is {card_sorted(chien)}\nAnd your hand is {card_sorted(player_alone)}\n\n\n"

# ------------------------------------------------------------------------------------------------------------

def Interface_pli(PliList, Winner, i):

    # create the window

    root = Tk()
    root.title("For all the player")
    root.config(background='#066504')
    Label(root, text=f"It was the round {i}\nThe winner is the player {Winner}", background='#066504', foreground='white').pack()

    # create the frame to display the cards

    frame = Frame(root)
    Images = []
    for i in PliList:

        def test(item0, item1):
            def test2():
                root.destroy()
            return test2
        photo = PhotoImage(file ="{}\\{}_{}.png".format(color_from_colorAbrevation(i[1]), i[0], color_from_colorAbrevation(i[1])), height=300, width=198).subsample(3)
        Images.append(photo)
        button = Button(frame, image = photo, command=test(i[0], i[1]))
        button.pack(side = LEFT)

    frame.pack(expand=YES)

    def test():
        root.destroy()
    Button(root, text='NEXT', command=test).pack(expand=YES)

    root.mainloop()

# ------------------------------------------------------------------------------------------------------------

def Interface_Label(title, sub_text):

    # create the window

    root = Tk()
    root.title("FOR ALL THE PLAYERS")
    root.config(background='#066504')

    Label(root, text=title, font=("Courrier", 20), background='#066504', foreground='white').pack(expand=YES)
    Label(root, text=sub_text, font=("Courrier", 10), background='#066504', foreground='white').pack(expand=YES)
    
    def test():
        root.destroy()
    Button(root, text='NEXT', command=test).pack(expand=YES)

    root.mainloop()


