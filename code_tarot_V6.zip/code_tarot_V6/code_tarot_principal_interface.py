from code_tarot_definition import *
from code_tarot_interface import *


def game():

    p1 = []
    p2 = []
    p3 = []
    p4 = []
    chien = []

    # étape 1 : creation du jeu
    finalDeck = cardDeck()

    # étape 2 : chien (en anglais ?)
    draw(6, chien, finalDeck)

    # étape 3 : distribution
    p1 = card_sorted(distribution(p1, p1, p2, p3, p4, finalDeck))
    p2 = card_sorted(distribution(p2, p1, p2, p3, p4, finalDeck))
    p3 = card_sorted(distribution(p3, p1, p2, p3, p4, finalDeck))
    p4 = card_sorted(distribution(p4, p1, p2, p3, p4, finalDeck))

    # étape 4 : organisation du chien
    for i in range(1,5):
        playercards = wichplayer(i, p1, p2, p3, p4)
        playerrank = i
        player_choice = CardsInterface_start(playercards, chien, 'here are your cards', 'here are the dog', 'do you want to take the dog ?', f'ONLY FOR PLAYER {playerrank}')
        list(player_choice.strip())
        if player_choice[0] == "Y" or player_choice[0] == "y" or player_choice[0] == "O" or player_choice[0] == "o":
            break

    if player_choice[0] == "N" or player_choice[0] == "n":
        return '\nNo one wants to take the dog\nGAME OVER'

    player_alone = wichplayer(playerrank, p1, p2, p3, p4)

# --------------------------------------------------------------------------------------------
    """
    print(creation_of_the_chien(chien, player_alone))

    if wich_player == 1:
        p1 = card_sorted(player_alone)
    if wich_player == 2:
        p2 = card_sorted(player_alone)
    if wich_player == 3:
        p3 = card_sorted(player_alone)
    if wich_player == 4:
        p4 = card_sorted(player_alone)


    # étape 5 : la partie commence
    print('\n\n\n\n\n\n\n\n\n\n\n\n\n\nthe game begin ! \n')

    p1cards = []
    p2cards = []
    p3cards = []
    p4cards = []
    whoPlaysFirst = [p1, p2, p3, p4]

    for i in range(18):

        print(f'\n\n\nround {i+1}\n\n')
        m = 0
        pli = []

        for playerCard in whoPlaysFirst:

            if playerCard == p1: m = 1
            elif playerCard == p2: m = 2
            elif playerCard == p3: m = 3
            elif playerCard == p4: m = 4

            playerCard = cards_that_the_player_can_play(playerCard, pli)

            #-----------------------------------------------------------------------------------------------
            #pn_r = CardsInterface_round(playerCard, pli, f'player {m}; here are the cards you can play', 'and here are the cards played by the other players for this round')
            #-----------------------------------------------------------------------------------------------
            print(f'player {m} with your hand you can only play :\n{playerCard}')
            #pn_r = int(input("what do you want to play ?"))
            #-----------------------------------------------------------------------------------------------
            pn_r = -1
            #-----------------------------------------------------------------------------------------------
            
            pli.append(playerCard[pn_r])
            card = playerCard[pn_r]
            
            if m == 1: playerCard = p1
            elif m == 2: playerCard = p2
            elif m == 3: playerCard = p3
            elif m == 4: playerCard = p4

            playerCard.remove(card)

            print(f'The current pli is :\n {pli}\n')


    return f"FINALLY:\n\nplayer 1 got: {p1cards}\nplayer 2 got: {p2cards}\nplayer 3 got: {p3cards}\nplayer 4 got: {p4cards}"
    """
