import random
from random import randint


def cardDeck():
    """create and shuffle a deck of cards

    Returns:
        list: list of cards
    """
    color = ["D","H","C","S"]
    high_values = ["1","2","3","4","5","6","7","8","9","10","J","C","Q","K"]
    deck = [(x,y) for y in color for x in high_values]
    for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
        deck.append((str(x),"A"))
    deck.append('fool')
    random.shuffle(deck)
    return deck


def distribution(listA, listP1, listP2, listP3, listP4, Deck):
    """ to distribute the cards of the deck to the players (3 by 3)

    Args:
        listA (list): emplty list to fill with the cards of the player
        listP1 (list): deck of player 1 (empty)
        listP2 (list): deck of player 2 (empty)
        listP3 (list): deck of player 3 (empty)
        listP4 (list): deck of player 4 (empty)
        Deck (list): deck cf def cardDexk()

    Returns:
        list: the player's hand
    """

    if listA == listP1:
        for x in [0, 1, 2]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    if listA == listP2:
        for x in [3, 4, 5]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    if listA == listP3:
        for x in [6, 7, 8]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    if listA == listP4:
        for x in [9, 10, 11]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    return listA


def card_classification():
    """create a dictionnary with cards and corresponding values (from 0 to 78)
    in ascending order

    Returns:
        dict:
    """
    color = ["D","H","C","S"]
    high_values = ["1","2","3","4","5","6","7","8","9","10","J","C","Q","K"]
    deck = [(x,y) for y in color for x in high_values]
    for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
        deck.append((str(x),"A"))
    deck.append('fool')

    number = []
    for x in range(79):
        x = x + 1
        number.append(x)
        
    classification = {x:y for x,y in zip(deck, number)}

    return classification


def reverse_card_classification():
    """ create a dictionnary with values (from 0 to 78) and corresponding cards
    in ascending order

    Returns:
        dict:
    """
    color = ["D","H","C","S"]
    high_values = ["1","2","3","4","5","6","7","8","9","10","J","C","Q","K"]
    deck = [(x,y) for y in color for x in high_values]
    for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
        deck.append((str(x),"A"))
    deck.append('fool')

    number = []
    for x in range(79):
        x = x + 1
        number.append(x)

    reverse_classification = {x:y for x,y in zip(number, deck)}

    return reverse_classification


def card_sorted(listB):
    """sort the cards

    Args:
        listB (list): list with cards

    Returns:
        list: list with sorted cards
    """
    
    transformation = card_classification()
    reverse_transformation = reverse_card_classification()

    nb_sort = []
    for i in listB:
        nb_sort_i = transformation[i]
        nb_sort.append(nb_sort_i)
    nb_sort.sort()

    listC = []
    for j in nb_sort:
        card_sort_j = reverse_transformation[j]
        listC.append(card_sort_j)

    return listC


def list_transormation_nb(listB):
    """transform a list of cards by a list of number
    ! not the not their tarot value but just a ranking {('1','D'):1, ('1','D'):2, ect...}

    Args:
        listB (list): list of cards

    Returns:
        list: list of number (from 0 to 78)
    """
    
    transformation = card_classification()

    nb_list = []
    for i in listB:
        nb_list_i = transformation[i]
        nb_list.append(nb_list_i)
    
    return nb_list


def reverse_list_transormation_nb(listC):
    """cf def list_transormation_nb() = the inverse
    """
    
    reverse_transformation = reverse_card_classification()
    
    list_card = []
    for j in listC:
        card = reverse_transformation[j]
        list_card.append(card)
        
    return list_card


def winner(pli):
    """return the player who has the best cards in list pli

    Args:
        pli (list): list of cards

    Returns:
        int: player's number (1, 2, 3 or 4)
    """
    x = card_sorted(pli)[len(pli)-1]
    for nbCard in range(0, len(pli)):
        if x == pli[nbCard]:
            player = nbCard + 1
            break
    return player


def runningOrder(listA, n):
    """allow the player who win the previous round to begin,
    => reorganises the running order

    Args:
        listA (list): previous running order
        n (int): the number of the winner of the round (1, 2, 3 or 4)

    Returns:
        list: the new runnig order (e.g : [3, 4, 1, 2])
    """
    listB = []
    for i in range(-1, len(listA)-1):
        if i + n <= 3:
            listB.append(listA[i + n])
        else:
            listB.append(listA[i + n - 4])
    return listB


def PlayersWantToPlay():
    """ask the players if they want to play
    yes = TRUE
    no = FALSE

    Returns:
        bool:
    """
    WantToPlay = str(input("\n\n\n\ndo you want to play tarot? (Yes/No)"))
    list(WantToPlay.strip())

    if WantToPlay[0] == "Y" or WantToPlay[0] == "y":
        print("Ok the game begin, the rules are : ...")
        running = True
    elif WantToPlay[0] == "N" or WantToPlay[0] == "n":
        print("Ok goodbye")
        running = False
    else:
        print("Sorry I didn't understand, try again")
        running = False
    return running


def PointsCount(listA):
    """according to the points of the tarot the function assigns to a list of cards its value in the tarot (float)

    Args:
        listA (list): list of cards

    Returns:
        float: nb of points in listA
    """

    nb = list_transormation_nb(listA)
    listPoints = 0

    for i in nb:
        if i == 11 or i == 25 or i == 39 or i == 53:
            listPoints = listPoints + 2
        elif i == 12 or i == 26 or i == 40 or i == 54:
            listPoints = listPoints + 3
        elif i == 13 or i == 27 or i == 41 or i == 55:
            listPoints = listPoints + 4
        elif i == 14 or i == 28 or i == 42 or i == 56:
            listPoints = listPoints + 5
        elif i == 57 or i == 77 or i == 78:
            listPoints = listPoints + 5
        else:
            listPoints = listPoints + 0.5

    return listPoints




# ---------------------------------------------------------------------------------------------------------------------------------------
# definition that have to be replaced (to be deleted at the end)


''' authorised_cards '''
def allowed_cards(hand, a, b):
    """reduce a list of cards (ranging from 0 to 78 CF def card_classification())
    to a smaller one (ranging from a to b)

    Args:
        hand (list): player's cards
        a (int): 
        b (int):

    Returns:
        list: list of cards (whose value is between a and b)
    """
    
    hand_number = list_transormation_nb(hand)

    allowed_cards = []

    for i in range(a, b):
        for j in range(0,len(hand)):
            if hand_number[j] == i:
                allowed_cards.append(hand_number[j])

    if allowed_cards == []:
        for i in range(57,79):
            for j in range(0,len(hand)):
                if hand_number[j] == i:
                    allowed_cards.append(hand_number[j])  

    return reverse_list_transormation_nb(allowed_cards)


''' INTERFACE_creation_of_the_chien '''
def creation_of_the_chien(chien, player_alone):
    """the procedure for creating the dog
    (exchange the cards of his deck with the dog's, at the end there must be no assets or kings in the dog)
    the def :
    - verify that the dog is correct
    - propose to the player to exchange his cards with the cards of the 'dog'

    Args:
        chien (list): list for the 'dog'
        player_alone (list): list represent the player's hand

    Returns:
        list: 2 lits : the correct 'dog' and the player's hand
    """
    print("\n\nBe careful! You cannot put an asset or a king in the chien."
    "\nTo replace a card in the chien or in your hand give the rank number of the card."
    "\nFrom 0 to 5 for the dog and from 0 to 17 for your deck.\n\n")
    m = 1
    while m == 1:

        print(player_choice_for_the_chien(chien, player_alone))

        transformation = card_classification()

        listG = []
        for i in chien:
            value_i = transformation[i]
            listG.append(value_i)

        m = 0
        for i in range(0,6):
            if listG[i] == 14 or listG[i] == 28 or listG[i] == 42 or listG[i] == 56:
                m = 1
            for n in range(57,79):
                if listG[i] == n:
                    m = 1

    end = str(input(f"\nyour hand is :{player_alone}\nand the chien is :{chien}\n\nIs it ok ?"))
    list(end.strip())

    while end[0] == "N" or end[0] == "n":

        print(player_choice_for_the_chien(chien, player_alone))

        end = str(input(f"\nyour hand is :{player_alone}\nand the chien is :{chien}\n\nIs it ok ?"))
        list(end.strip())
    
    return f"\n\n\n\nfinally the chien is {card_sorted(chien)}\nAnd your hand is {card_sorted(player_alone)}\n\n\n"


''' moved in INTERFACE_creation_of_the_chien '''
def player_choice_for_the_chien(listA, listB):
    """exchange one card from a listA with one from listB

    Args:
        listA (list):
        listB (list):

    Returns:
        the 2 lists when the cards have been exchanged
    """

    card_chien = int(input(f"in the chien {listA} wich card do you want to take ? "))
    card_hand = int(input(f"which card in you hand {listB} do you want to replace ?"))

    card_chosen_from_the_chien = listA[card_chien]
    card_chosen_from_the_hand = listB[card_hand]

    listA.remove(card_chosen_from_the_chien)
    listA.append(card_chosen_from_the_hand)
    listB.remove(card_chosen_from_the_hand)
    listB.append(card_chosen_from_the_chien)

    return listA, listB




# ---------------------------------------------------------------------------------------------------------------------------------------
# definition that have been corrected 
# or 
# those that will replace the previous ones
# or
# the new ones



def draw(n, chien, Deck):
    """ to choose in Deck a number (n) of cards, remove to Deck and add to chien

    Args:
        n (int): number of cards to draw
        chien (list): add the cards at this list
        Deck (list): remove the cards from this list

    Returns:
        list: list with the choosen cards
    """

    lastRange = 78
    for _ in range(n) :
        lastRange -= 1
        y = random.randint(0,lastRange) 
        chien.append(Deck[y])
        Deck.remove(Deck[y])
    return chien


def color_from_colorAbrevation(ListElement):
    if ListElement == 'H': return 'coeur'
    elif ListElement == 'D': return 'carreaux'
    elif ListElement == 'C': return 'trefles'
    elif ListElement == 'S': return 'piques'
    elif ListElement == 'A': return 'Atouts'


def authorised_cards(hand, color):
    """ Remove from a list of cards (hand) the cards that the players cannot play

    Args:
        hand (list): player's cards
        color (str): colour of authorised cards

    Returns:
        list: list of allowed cards
    """


    hand_reduced = []
    for j in hand:
        if j[1] == color: hand_reduced.append(j)

    return hand_reduced


def cards_that_the_player_can_play(PlayerCards, cardsPlayed):
    """
    - show the cards that the player can play in function of the cards played by the others previously
    - DURING rounds

    Args:
        PlayerCards (list): cards of the player
        cardsPlayed (list): cards previously played

    Returns:
        list: cards that the player can use
    """
    
    if PlayerCards[-1] == 'fool':
        if cardsPlayed == [] or cardsPlayed == ['fool']: FinalCard = PlayerCards
        else:
            for color in ['H', 'D', 'C', 'S', 'A']:
                if cardsPlayed[0][1] == color:
                    FinalCard = authorised_cards(PlayerCards, color)
                    FinalCard.append('fool')

        if FinalCard == ['fool']: 
            if authorised_cards(PlayerCards, 'A') == []: FinalCard = PlayerCards
            else:
                FinalCard = authorised_cards(PlayerCards, 'A')
                FinalCard.append('fool')
    else:
        if cardsPlayed == [] or cardsPlayed == ['fool']: FinalCard = PlayerCards
        else:
            for color in ['H', 'D', 'C', 'S', 'A']:
                if cardsPlayed[0][1] == color: FinalCard = authorised_cards(PlayerCards, color)

        if FinalCard == []: 
            if authorised_cards(PlayerCards, 'A') == []: FinalCard = PlayerCards
            else: FinalCard = authorised_cards(PlayerCards, 'A')


    return FinalCard


def wichplayer(rank, p1, p2, p3, p4):
    if rank == 1: return p1
    elif rank == 2: return p2
    elif rank == 3: return p3
    elif rank == 4: return p4
    elif rank == 5: return []



