from code_tarot_definition import *
from code_tarot_interface import *


def game():
    # étape 1 : creation du jeu
    p1 = []
    p2 = []
    p3 = []
    p4 = []
    chien = []
    finalDeck = cardDeck()
    print(f'final deck : {finalDeck}\n\n\n') 


    # étape 2 : chien (en anglais ?)
    chien = []
    draw(6, chien, finalDeck)
    print(f'this is the "chien" : \n{chien}\n\n\n\n\n')


    # étape 3 : distribution
    i = 0
    for j in [p1, p2, p3, p4]:
        i = i + 1
        print(f'Player {i} has \n{distribution(j, p1, p2, p3, p4, finalDeck)}\n\n')


    # étape 3 bis : trier les cartes
    print("\n\n\n\n\n\n\nCARDS SORTING :\n\n")
    m = 0
    for n in [p1, p2, p3, p4]:
        m = m + 1
        print(f'Player {m} cards sorted : \n{card_sorted(n)}\n\n')

    p1 = card_sorted(p1)
    p2 = card_sorted(p2)
    p3 = card_sorted(p3)
    p4 = card_sorted(p4)

    # étape 4 : organisation du chien
    for i in range(1,5):
        wich_player = i
        player_choice = str(input((f'player {i} do you want to take the "chien" ? (yes/no)')))
        list(player_choice.strip())
        if player_choice[0] == "Y" or player_choice[0] == "y" or player_choice[0] == "O" or player_choice[0] == "o":
            print("\nOK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
            break

    if player_choice[0] == "N" or player_choice[0] == "n":
        return '\nNo one wants to take the dog\nGAME OVER'

    if wich_player == 1:
        player_alone = p1
    elif wich_player == 2:
        player_alone = p2
    elif wich_player == 3:
        player_alone = p3
    elif wich_player == 4:
        player_alone = p4
    elif wich_player == 5:
        player_alone = []
        chien = []

    print(creation_of_the_chien(chien, player_alone))

    if wich_player == 1:
        p1 = card_sorted(player_alone)
    if wich_player == 2:
        p2 = card_sorted(player_alone)
    if wich_player == 3:
        p3 = card_sorted(player_alone)
    if wich_player == 4:
        p4 = card_sorted(player_alone)


    # étape 5 : la partie commence
    print('\n\n\n\n\n\n\n\n\n\n\n\n\n\nthe game begin ! \n')

    p1cards = []
    p2cards = []
    p3cards = []
    p4cards = []
    whoPlaysFirst = [p1, p2, p3, p4]

    for i in range(18):

        print(f'\n\n\nround {i+1}\n\n')
        m = 0
        pli = []

        for playerCard in whoPlaysFirst:

            if playerCard == p1: m = 1
            elif playerCard == p2: m = 2
            elif playerCard == p3: m = 3
            elif playerCard == p4: m = 4

            playerCard = cards_that_the_player_can_play(playerCard, pli)

            #-----------------------------------------------------------------------------------------------
            #pn_r = CardsInterface_round(playerCard, pli, f'player {m}; here are the cards you can play', 'and here are the cards played by the other players for this round')
            #-----------------------------------------------------------------------------------------------
            print(f'player {m} with your hand you can only play :\n{playerCard}')
            #pn_r = int(input("what do you want to play ?"))
            #-----------------------------------------------------------------------------------------------
            pn_r = -1
            #-----------------------------------------------------------------------------------------------
            
            pli.append(playerCard[pn_r])
            card = playerCard[pn_r]
            
            if m == 1: playerCard = p1
            elif m == 2: playerCard = p2
            elif m == 3: playerCard = p3
            elif m == 4: playerCard = p4

            playerCard.remove(card)

            print(f'The current pli is :\n {pli}\n')

        #étape 5 bis : qui gagne ?
        print(f'the best card is {pli[winner(pli)-1]}')

        whoPlaysFirst = runningOrder(whoPlaysFirst, winner(pli))
        
        NbWinner = '0'
        if whoPlaysFirst[0] == p1:
            NbWinner = '1'
            for card in range(0, 4):
                p1cards.append(pli[card])
        elif whoPlaysFirst[0] == p2:
            NbWinner = '2'
            for card in range(0, 4):
                p2cards.append(pli[card])
        elif whoPlaysFirst[0] == p3:
            NbWinner = '3'
            for card in range(0, 4):
                p3cards.append(pli[card])
        elif whoPlaysFirst[0] == p4:
            NbWinner = '4'
            for card in range(0, 4):
                p4cards.append(pli[card])

        print(f'the best card is {pli[winner(pli)-1]} and the winner is the player {NbWinner}')
    
    #étape 6 : compter les points
    
    dictA = reverse_card_classification()
    j = 0
    nbOfBou = 0
    for i in [p1cards, p2cards, p3cards, p4cards]:
        j = j+1
        if j == wich_player:
            
            for m in i:
                if dictA.get(m) == 77: nbOfBou = nbOfBou + 1
                if dictA.get(m) == 78: nbOfBou = nbOfBou + 1
                if dictA.get(m) == 57: nbOfBou = nbOfBou + 1
            
            print(f"\n\n\n\nplayer {j} you took the dog with {nbOfBou} oudlers and you finished with {PointsCount(i)} points")
            
            if nbOfBou == 0:
                if PointsCount(i) >= 56: print("You win\n\n\n") 
                else: print("You loose\n\n\n")
            elif nbOfBou == 1:
                if PointsCount(i) >= 51: print("You win\n\n\n") 
                else: print("You loose\n\n\n")
            elif nbOfBou == 2:
                if PointsCount(i) >= 41: print("You win\n\n\n") 
                else: print("You loose\n\n\n")
            elif nbOfBou == 5:
                if PointsCount(i) >= 36: print("You win\n\n\n") 
                else: print("You loose\n\n\n")


    return f"FINALLY:\n\nplayer 1 got: {p1cards}\nplayer 2 got: {p2cards}\nplayer 3 got: {p3cards}\nplayer 4 got: {p4cards}"

