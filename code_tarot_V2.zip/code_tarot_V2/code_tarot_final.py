from code_tarot_principal import game

def PlayersWantToPlay():
    WantToPlay = str(input("do you want to play tarot? (Yes/No)"))
    list(WantToPlay.strip())

    if WantToPlay[0] == "Y" or WantToPlay[0] == "y":
        print("Ok the game begin, the rules are : ...")
        running = True
    elif WantToPlay[0] == "N" or WantToPlay[0] == "n":
        print("Ok goodbye")
        running = False
    else:
        print("Sorry I didn't understand, try again")
        running = False
    return running

while PlayersWantToPlay():
    print(game())
    #compter les points et donner le gagnants
