import random
from random import randint
from code_tarot_definition import cardDeck
from code_tarot_definition import distribution
from code_tarot_definition import draw
from code_tarot_definition import card_sorted
from code_tarot_definition import creation_of_the_chien
from code_tarot_definition import allowed_cards
from code_tarot_definition import list_transormation_nb
from code_tarot_definition import winner
from code_tarot_definition import runningOrder

# étape 1 : creation du jeu
p1 = []
p2 = []
p3 = []
p4 = []
chien = []
finalDeck = cardDeck()
print(f'final deck : {finalDeck}\n\n\n') 


# étape 2 : chien (en anglais ?)
chien = []
draw(6, chien, finalDeck)
print(f'this is the "chien" : \n{chien}\n\n\n\n\n')


# étape 3 : distribution
i = 0
for j in [p1, p2, p3, p4]:
    i = i + 1
    print(f'Player {i} has \n{distribution(j, p1, p2, p3, p4, finalDeck)}\n\n')


# étape 3 bis : trier les cartes
print("\n\n\n\n\n\n\nCARDS SORTING :\n\n")
m = 0
for n in [p1, p2, p3, p4]:
    m = m + 1
    print(f'Player {m} cards sorted : \n{card_sorted(n)}\n\n')

p1 = card_sorted(p1)
p2 = card_sorted(p2)
p3 = card_sorted(p3)
p4 = card_sorted(p4)

# étape 4 : organisation du chien
for i in range(1,5):
    wich_player = i
    player_choice = str(input((f'player {i} do you want to take the "chien" ? (yes/no)')))
    list(player_choice.strip())
    if player_choice[0] == "Y" or player_choice[0] == "y" or player_choice[0] == "O" or player_choice[0] == "o":
        print("\nOK\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        break

if player_choice[0] == "N" or player_choice[0] == "n":
    print('\n\n\nnobody wants to take the chien \nGAME OVER')
    wich_player = 5
    # mettre fin au jeu et commencer une autre partie

if wich_player == 1:
    player_alone = p1
elif wich_player == 2:
    player_alone = p2
elif wich_player == 3:
    player_alone = p3
elif wich_player == 4:
    player_alone = p4
elif wich_player == 5:
    player_alone = []
    chien = []

print(creation_of_the_chien(chien, player_alone))

if wich_player == 1:
    p1 = card_sorted(player_alone)
if wich_player == 2:
    p2 = card_sorted(player_alone)
if wich_player == 3:
    p3 = card_sorted(player_alone)
if wich_player == 4:
    p4 = card_sorted(player_alone)


# étape 5 : la partie commence
print('\n\n\n\n\n\n\n\n\n\n\n\n\n\nthe game begin ! \n')

whoPlaysFirst = [p1, p2, p3, p4]
for i in range(18):

    print(f'\n\n\nround {i+1}\n\n')
    m = 0
    u = -1
    pli = []


    for n in whoPlaysFirst:

        if n == p1: m = 1
        elif n == p2: m = 2
        elif n == p3: m = 3
        elif n == p4: m = 4

        no_cards = 0
        pli_transormation_nb = list_transormation_nb(pli)

        if pli == []:
            n = allowed_cards(n, 1, 79)

        else:

            for i in range(1,15):
                if pli_transormation_nb[0] == i:
                    n = allowed_cards(n, 1, 15)
                else: no_cards = no_cards + 1

            for i in range(15,29):
                if pli_transormation_nb[0] == i:
                    n = allowed_cards(n, 15, 29)
                else: no_cards = no_cards + 1

            for i in range(29,43):
                if pli_transormation_nb[0] == i:
                    n = allowed_cards(n, 29, 43)
                else: no_cards = no_cards + 1

            for i in range(43,57):
                if pli_transormation_nb[0] == i:
                    n = allowed_cards(n, 43, 57)
                else: no_cards = no_cards + 1

            for i in range(57,79):                       
                if pli_transormation_nb[0] == i:
                    n = allowed_cards(n, 57, 79)
                else: no_cards = no_cards + 1

            if no_cards == 5:
                for i in range(57,79):
                    if pli_transormation_nb[0] == i:
                        n = allowed_cards(n, 57, 79)
                    else: n = allowed_cards(n, 1, 79)        #faire def pour bien jouer les atouts

        print(f'player {m} with your hand you can only play :\n{n}')

        pn_r = int(input("what do you want to choose ?"))
        pli.append(n[pn_r])
        card = n[pn_r]
        
        if m == 1: n = p1
        elif m == 2: n = p2
        elif m == 3: n = p3
        elif m == 4: n = p4

        n.remove(card)

        print(f'The current pli is :\n {pli}\n')       #comment on dit pli/levée en anglais ?

    #étape 5 bis : qui gagne ?
    print(f'the best card is {pli[winner(pli)-1]}')

    whoPlaysFirst = runningOrder(whoPlaysFirst, winner(pli))

    NbWinner = '0'
    if whoPlaysFirst[0] == p1: NbWinner = '1'
    elif whoPlaysFirst[0] == p2: NbWinner = '2'
    elif whoPlaysFirst[0] == p3: NbWinner = '3'
    elif whoPlaysFirst[0] == p4: NbWinner = '4'

    print(f'the best card is {pli[winner(pli)-1]} and the winner is the player {NbWinner}')