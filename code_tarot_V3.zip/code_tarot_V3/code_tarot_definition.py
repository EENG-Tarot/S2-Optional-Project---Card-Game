import random
from random import randint


def cardDeck():
    color = ["D","H","C","S"]
    high_values = ["1","2","3","4","5","6","7","8","9","10","V","C","Q","K"]
    deck = [(x,y) for y in color for x in high_values]
    for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
        deck.append(str(x))
    deck.append('fool')
    random.shuffle(deck)
    return deck


def distribution(listA, listP1, listP2, listP3, listP4, Deck):

    if listA == listP1:
        for x in [0, 1, 2]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    if listA == listP2:
        for x in [3, 4, 5]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    if listA == listP3:
        for x in [6, 7, 8]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    if listA == listP4:
        for x in [9, 10, 11]:
            for y in [0, 12, 24, 36, 48, 60]:
                listA.append(Deck[x + y])
    return listA


def draw(n, chien, Deck):
    for _ in range(n) :
        y = random.randint(0,75)  #j'ai mis entre 0 et 75 car il ne faut pas que les 3 dernières cartes du jeu soit distribuées dans le chien. non ? à verifier
        chien.append(Deck[y])
        Deck.remove(Deck[y])
    return chien


def card_classification():
    color = ["D","H","C","S"]
    high_values = ["1","2","3","4","5","6","7","8","9","10","V","C","Q","K"]
    deck = [(x,y) for y in color for x in high_values]
    for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
        deck.append(str(x))
    deck.append('fool')

    number = []
    for x in range(79):
        x = x + 1
        number.append(x)
        
    classification = {x:y for x,y in zip(deck, number)}

    return classification


def reverse_card_classification():
    color = ["D","H","C","S"]
    high_values = ["1","2","3","4","5","6","7","8","9","10","V","C","Q","K"]
    deck = [(x,y) for y in color for x in high_values]
    for x in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]:
        deck.append(str(x))
    deck.append('fool')

    number = []
    for x in range(79):
        x = x + 1
        number.append(x)

    reverse_classification = {x:y for x,y in zip(number, deck)}

    return reverse_classification


def card_sorted(listB):
    
    transformation = card_classification()
    reverse_transformation = reverse_card_classification()

    nb_sort = []
    for i in listB:
        nb_sort_i = transformation[i]
        nb_sort.append(nb_sort_i)
    nb_sort.sort()

    listC = []
    for j in nb_sort:
        card_sort_j = reverse_transformation[j]
        listC.append(card_sort_j)

    return listC


def player_choice_for_the_chien(listA, listB):

    card_chien = int(input(f"in the chien {listA} wich card do you want to take ? "))
    card_hand = int(input(f"which card in you hand {listB} do you want to replace ?"))

    card_chosen_from_the_chien = listA[card_chien]
    card_chosen_from_the_hand = listB[card_hand]

    listA.remove(card_chosen_from_the_chien)
    listA.append(card_chosen_from_the_hand)
    listB.remove(card_chosen_from_the_hand)
    listB.append(card_chosen_from_the_chien)

    return listA, listB


def creation_of_the_chien(chien, player_alone):
    print("\n\nBe careful! You cannot put an asset or a king in the chien."
    "\nTo replace a card in the chien or in your hand give the rank number of the card."
    "\nFrom 0 to 5 for the dog and from 0 to 17 for your deck.\n\n")
    m = 1
    while m == 1:

        print(player_choice_for_the_chien(chien, player_alone))

        transformation = card_classification()

        listG = []
        for i in chien:
            value_i = transformation[i]
            listG.append(value_i)

        m = 0
        for i in range(0,6):
            if listG[i] == 14 or listG[i] == 28 or listG[i] == 42 or listG[i] == 56:
                m = 1
            for n in range(57,79):
                if listG[i] == n:
                    m = 1

    end = str(input(f"\nyour hand is :{player_alone}\nand the chien is :{chien}\n\nIs it ok ?"))
    list(end.strip())

    while end[0] == "N" or end[0] == "n":

        print(player_choice_for_the_chien(chien, player_alone))

        end = str(input(f"\nyour hand is :{player_alone}\nand the chien is :{chien}\n\nIs it ok ?"))
        list(end.strip())
    
    return f"\n\n\n\nfinally the chien is {card_sorted(chien)}\nAnd your hand is {card_sorted(player_alone)}\n\n\n"


def list_transormation_nb(listB):
    
    transformation = card_classification()

    nb_list = []
    for i in listB:
        nb_list_i = transformation[i]
        nb_list.append(nb_list_i)
    
    return nb_list


def reverse_list_transormation_nb(listC):
    
    reverse_transformation = reverse_card_classification()
    
    list_card = []
    for j in listC:
        card = reverse_transformation[j]
        list_card.append(card)
        
    return list_card


def allowed_cards(hand, a, b):
    
    hand_number = list_transormation_nb(hand)

    allowed_cards = []

    for i in range(a, b):
        for j in range(0,len(hand)):
            if hand_number[j] == i:
                allowed_cards.append(hand_number[j])

    if allowed_cards == []:
        for i in range(57,79):
            for j in range(0,len(hand)):
                if hand_number[j] == i:
                    allowed_cards.append(hand_number[j])  

    return reverse_list_transormation_nb(allowed_cards)


def winner(pli):
    x = card_sorted(pli)[len(pli)-1]
    for nbCard in range(0, len(pli)):
        if x == pli[nbCard]:
            player = nbCard + 1
            break
    return player


def runningOrder(listA, n):
    listB = []
    for i in range(-1, len(listA)-1):
        if i + n <= 3:
            listB.append(listA[i + n])
        else:
            listB.append(listA[i + n - 4])
    return listB


def PlayersWantToPlay():
    WantToPlay = str(input("do you want to play tarot? (Yes/No)"))
    list(WantToPlay.strip())

    if WantToPlay[0] == "Y" or WantToPlay[0] == "y":
        print("Ok the game begin, the rules are : ...")
        running = True
    elif WantToPlay[0] == "N" or WantToPlay[0] == "n":
        print("Ok goodbye")
        running = False
    else:
        print("Sorry I didn't understand, try again")
        running = False
    return running

